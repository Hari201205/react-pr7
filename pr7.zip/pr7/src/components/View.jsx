import React, { useState } from 'react';
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';

const View = () => {
    const [employedata, setEmployedata] = useState(JSON.parse(localStorage.getItem('users')) || []);

    const deleteUser = (id) => {
        const updatedData = employedata.filter(item => item.id !== id);
        setEmployedata(updatedData);
        localStorage.setItem('users', JSON.stringify(updatedData));
        alert('Employee record deleted');
    };

    const deleteAllData = () => {
        setEmployedata([]);
        localStorage.removeItem('users');
        alert('All employee records deleted');
    };

    return (
        <div className='container col-lg-8'>
            <h2 align="center">Employee Data</h2>
            <div className="mb-2">
                <Link to='/'>
                    <button className='btn btn-success mr-2'>Add</button>
                </Link>
                <button onClick={deleteAllData} className='btn btn-danger mx-2' >Delete All Data</button>
            </div>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Status</th> {/* Added Status column */}
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {employedata.map((val) => (
                        <tr key={val.id}>
                            <td>{val.id}</td>
                            <td>{val.firstName}</td>
                            <td>{val.lastName}</td>
                            <td>{val.email}</td>
                            <td>{val.status}</td> {/* Added Status cell */}
                            <td>
                                <button onClick={() => deleteUser(val.id)} className='btn btn-danger'>Delete</button>
                                <Link to={`/edit/${val.id}`}>
                                    <button className='btn btn-success mx-2'>Edit</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default View;
