import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import '../style.css';
import { Link, useNavigate } from 'react-router-dom';

const Add = () => {
    const navigate = useNavigate();
    const [firstName, setfirstName] = useState('');
    const [lastName, setLastname] = useState('');
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState('active'); // Adding status state
    const [record, setRecord] = useState([]);

    const handelsubmit = (e) => {
        e.preventDefault();

        if (!firstName || !lastName || !email || !status) {
            alert('Please fill up all inputs');
            return false;
        }

        const obj = {
            id: Math.floor(Math.random() * 1000),
            firstName: firstName,
            lastName: lastName,
            email: email,
            status: status // Adding status to the object
        };

        const data = [...record, obj];
        setRecord(data);
        localStorage.setItem('users', JSON.stringify(data));

        alert('Employee added');

        setfirstName('');
        setLastname('');
        setEmail('');
        setStatus('active'); // Resetting status
        navigate('/view');
    };

    useEffect(() => {
        const allData = JSON.parse(localStorage.getItem('users')) || [];
        setRecord(allData);
    }, []);

    return (
        <div>
            <Form onSubmit={handelsubmit} className="container col-lg-5">
                <h2 align="center">Add Employee</h2>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Employee First Name</Form.Label>
                    <Form.Control value={firstName} onChange={(e) => setfirstName(e.target.value)} type="text" placeholder="First Name" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Employee Last Name</Form.Label>
                    <Form.Control value={lastName} onChange={(e) => setLastname(e.target.value)} type="text" placeholder="Last Name" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Employee Email Id</Form.Label>
                    <Form.Control value={email} onChange={(e) => setEmail(e.target.value)} type="text" placeholder="Email Id" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicStatus">
                    <Form.Label>Status</Form.Label>
                    <Form.Control as="select" value={status} onChange={(e) => setStatus(e.target.value)}>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </Form.Control>
                </Form.Group>
                <Button variant="primary" type="submit">
                    Add
                </Button>

                <Link to={'/view'}>
                    <Button className="btn btn-success viewbtn" type="submit">
                        View
                    </Button>
                </Link>
            </Form>
        </div>
    );
};

export default Add;
